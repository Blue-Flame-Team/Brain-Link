import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:brain_link/model/app_models.dart';
import 'package:brain_link/model/chat_message.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Streams
  Stream<List<Session>> getSessions() {
    return _db
        .collection('sessions')
        .orderBy('startTime', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => Session.fromMap(doc.data(), doc.id))
              .toList(),
        );
  }

  Stream<List<Post>> getPosts() {
    return _db
        .collection('posts')
        .orderBy('timeStamp', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => Post.fromMap(doc.data(), doc.id))
              .toList(),
        );
  }

  Stream<List<LibraryItem>> getLibraryItems() {
    return _db
        .collection('library')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => LibraryItem.fromMap(doc.data(), doc.id))
              .toList(),
        );
  }

  Stream<List<ChatItem>> getChats() {
    final currentUserId =
        FirebaseAuth.instance.currentUser?.uid ?? 'anonymous_id';

    return _db
        .collection('chats')
        .where('participants', arrayContains: currentUserId)
        .snapshots()
        .map((snapshot) {
          final chats = snapshot.docs.map((doc) {
            final data = doc.data();

            final pNames = data['participantNames'] as Map<String, dynamic>?;
            String displayName = data['participantName'] ?? 'مستخدم';
            if (pNames != null) {
              // Find the other user's name
              final otherNames = pNames.keys.where((k) => k != currentUserId);
              if (otherNames.isNotEmpty) {
                displayName = pNames[otherNames.first] ?? displayName;
              }
            }

            var item = ChatItem.fromMap(data, doc.id);
            return ChatItem(
              id: item.id,
              participantName: displayName,
              lastMessage: item.lastMessage,
              time: item.time,
              unreadCount: item.unreadCount,
              isOnline: item.isOnline,
              isGroup: item.isGroup,
              hasAttachment: item.hasAttachment,
            );
          }).toList();

          // Sort locally to avoid composite index requirement
          chats.sort((a, b) => b.time.compareTo(a.time));
          return chats;
        });
  }

  // Insert Methods
  Future<void> addPost(Post post) async {
    await _db.collection('posts').add(post.toMap());
  }

  Future<void> addSession(Session session) async {
    await _db.collection('sessions').add(session.toMap());
  }

  Future<void> addLibraryItem(LibraryItem item) async {
    await _db.collection('library').add(item.toMap());
  }

  // Interactions
  Future<void> toggleLikePost(
    String postId,
    List<String> currentLikes,
    String userId,
  ) async {
    if (currentLikes.contains(userId)) {
      await _db.collection('posts').doc(postId).update({
        'likedBy': FieldValue.arrayRemove([userId]),
        'likesCount': FieldValue.increment(-1),
      });
    } else {
      await _db.collection('posts').doc(postId).update({
        'likedBy': FieldValue.arrayUnion([userId]),
        'likesCount': FieldValue.increment(1),
      });
    }
  }

  Stream<List<ChatMessage>> getComments(String postId) {
    return _db
        .collection('posts')
        .doc(postId)
        .collection('comments')
        .orderBy('time', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => ChatMessage.fromMap(doc.data(), doc.id))
              .toList(),
        );
  }

  Future<void> addComment(String postId, ChatMessage comment) async {
    await _db
        .collection('posts')
        .doc(postId)
        .collection('comments')
        .add(comment.toMap());
    await _db.collection('posts').doc(postId).update({
      'commentsCount': FieldValue.increment(1),
    });
  }

  // Chats
  Stream<List<ChatMessage>> getChatMessages(String chatId) {
    return _db
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('time', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => ChatMessage.fromMap(doc.data(), doc.id))
              .toList(),
        );
  }

  Future<void> addChatMessage(
    String chatId,
    ChatMessage message,
    String text,
  ) async {
    await _db
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .add(message.toMap());
    await _db.collection('chats').doc(chatId).update({
      'lastMessage': text,
      'time': FieldValue.serverTimestamp(),
    });
  }

  Future<ChatItem> getOrCreateChat(
    String otherUserId,
    String otherUserName,
  ) async {
    final currentUserId =
        FirebaseAuth.instance.currentUser?.uid ?? 'anonymous_id';
    final currentUserName =
        FirebaseAuth.instance.currentUser?.displayName ?? 'المستخدم';

    final participants = [currentUserId, otherUserId]..sort();
    final chatId = participants.join('_');

    final doc = await _db.collection('chats').doc(chatId).get();
    if (!doc.exists) {
      final newChat = ChatItem(
        id: chatId,
        participantName: otherUserName, // Simplification for MVP
        lastMessage: 'بدأت المحادثة',
        time: DateTime.now(),
        unreadCount: 0,
        isOnline: false,
        isGroup: false,
        hasAttachment: false,
      );
      final chatData = newChat.toMap();
      chatData['participants'] = participants;
      chatData['participantNames'] = {
        currentUserId: currentUserName,
        otherUserId: otherUserName,
      };

      await _db.collection('chats').doc(chatId).set(chatData);
      return newChat;
    } else {
      final docData = doc.data()!;

      // Attempt to resolve correct display name for the current user
      final pNames = docData['participantNames'] as Map<String, dynamic>?;
      String displayName = docData['participantName'] ?? otherUserName;

      if (pNames != null) {
        displayName =
            pNames[otherUserId] ??
            pNames.values.firstWhere(
              (n) => n != currentUserName,
              orElse: () => displayName,
            );
      }

      var chat = ChatItem.fromMap(docData, doc.id);
      return ChatItem(
        id: chat.id,
        participantName: displayName,
        lastMessage: chat.lastMessage,
        time: chat.time,
        unreadCount: chat.unreadCount,
        isOnline: chat.isOnline,
        isGroup: chat.isGroup,
        hasAttachment: chat.hasAttachment,
      );
    }
  }

  // Seed Initial Data (only runs if data is empty)
  Future<void> seedDataIfEmpty() async {
    try {
      final sessionsSnapshot = await _db.collection('sessions').limit(1).get();
      if (sessionsSnapshot.docs.isEmpty) {
        await _seedSessions();
      }

      final postsSnapshot = await _db.collection('posts').limit(1).get();
      if (postsSnapshot.docs.isEmpty) {
        await _seedPosts();
      }

      final librarySnapshot = await _db.collection('library').limit(1).get();
      if (librarySnapshot.docs.isEmpty) {
        await _seedLibrary();
      }

      final chatsSnapshot = await _db.collection('chats').limit(1).get();
      if (chatsSnapshot.docs.isEmpty) {
        await _seedChats();
      }
    } catch (e) {
      // Ignored
    }
  }

  Future<void> _seedSessions() async {
    final batch = _db.batch();
    final data = [
      {
        'title': 'بناء تطبيقات واجهة مستخدم متقدمة',
        'hostName': 'سارة أحمد',
        'startTime': DateTime.now().subtract(const Duration(minutes: 15)),
        'isLive': true,
        'tags': ['Flutter', 'UI', 'UX'],
        'participantsCount': 23,
      },
      {
        'title': 'أساسيات بايثون',
        'hostName': 'عمر خالد',
        'startTime': DateTime.now().add(const Duration(minutes: 15)),
        'isLive': false,
        'tags': ['Python', 'Basics'],
        'participantsCount': 50,
      },
      {
        'title': 'مراجعة خوارزميات البحث المتقدمة Advanced Search',
        'hostName': 'أحمد محمد',
        'startTime': DateTime.now().subtract(const Duration(minutes: 15)),
        'isLive': true,
        'tags': ['Data Structures', 'Python'],
        'participantsCount': 12,
      },
      {
        'title': 'بناء تطبيق React من الصفر بخطوات عملية',
        'hostName': 'سارة عبدالرحمن',
        'startTime': DateTime.now().add(const Duration(hours: 4)),
        'isLive': false,
        'tags': ['Frontend', 'React'],
        'participantsCount': 45,
      },
      {
        'title': 'حل تحديات LeetCode الأسبوعية - نقاش مفتوح',
        'hostName': 'عمر خالد',
        'startTime': DateTime.now().subtract(const Duration(minutes: 45)),
        'isLive': true,
        'tags': ['Problem Solving', 'C++'],
        'participantsCount': 8,
      },
    ];

    for (var mapItem in data) {
      batch.set(_db.collection('sessions').doc(), mapItem);
    }
    await batch.commit();
  }

  Future<void> _seedPosts() async {
    final batch = _db.batch();
    final data = [
      {
        'authorName': 'طارق محمود',
        'authorRole': 'مطور واجهات',
        'timeStamp': DateTime.now().subtract(const Duration(hours: 2)),
        'content':
            'لقد كنت أستكشف إمكانيات Tailwind CSS في المشاريع الكبيرة، ويبدو أن تنظيم المتغيرات (Tokens) هو المفتاح للحفاظ على نظافة الكود. إليكم مثالاً بسيطاً:',
        'hasCodeSnippet': true,
        'snippetCode':
            "module.exports = {\n  theme: {\n    extend: {\n      colors: {\n        'brand-primary': '#3D5AFE',\n      }\n    }\n  }\n}",
        'likesCount': 42,
        'commentsCount': 8,
      },
      {
        'authorName': 'مي الدوسري',
        'authorRole': 'مهندسة برمجيات',
        'timeStamp': DateTime.now().subtract(const Duration(hours: 5)),
        'content':
            'هل يفضل أحدكم استخدام Grid بدلاً من Flexbox في تخطيط لوحات التحكم؟ أجد أن Grid يوفر تحكماً أدق في الشاشات المعقدة.',
        'hasCodeSnippet': false,
        'snippetCode': '',
        'likesCount': 24,
        'commentsCount': 15,
      },
    ];
    for (var mapItem in data) {
      batch.set(_db.collection('posts').doc(), mapItem);
    }
    await batch.commit();
  }

  Future<void> _seedLibrary() async {
    final batch = _db.batch();
    final data = [
      {
        'title': 'دليل React المتقدم',
        'type': 'PDF',
        'size': '4.2 MB',
        'rating': '4.9',
        'views': '1.2k',
      },
      {
        'title': 'قوالب Tailwind وتصميمات فريدة',
        'type': 'ZIP',
        'size': '12.5 MB',
        'rating': '4.7',
        'views': '850',
      },
    ];
    for (var mapItem in data) {
      batch.set(_db.collection('library').doc(), mapItem);
    }
    await batch.commit();
  }

  Future<void> _seedChats() async {
    final batch = _db.batch();
    final data = [
      {
        'participantName': 'نورة العبدالله',
        'lastMessage': 'هل يمكنك مراجعة الكود الأخير؟',
        'time': DateTime.now().subtract(const Duration(hours: 1)),
        'unreadCount': 3,
        'isOnline': true,
        'isGroup': false,
        'hasAttachment': false,
      },
      {
        'participantName': 'أحمد حسن',
        'lastMessage': 'تمام، سأرسل لك الملفات غداً.',
        'time': DateTime.now().subtract(const Duration(days: 1)),
        'unreadCount': 0,
        'isOnline': false,
        'isGroup': false,
        'hasAttachment': false,
      },
      {
        'participantName': 'فريق التطوير',
        'lastMessage': 'ياسر: تم رفع التحديثات على السيرفر',
        'time': DateTime.now().subtract(const Duration(days: 3)),
        'unreadCount': 0,
        'isOnline': true,
        'isGroup': true,
        'hasAttachment': false,
      },
      {
        'participantName': 'سارة محمد',
        'lastMessage': 'صورة التصميم الجديد',
        'time': DateTime.now().subtract(const Duration(days: 10)),
        'unreadCount': 0,
        'isOnline': false,
        'isGroup': false,
        'hasAttachment': true,
      },
    ];
    for (var mapItem in data) {
      batch.set(_db.collection('chats').doc(), mapItem);
    }
    await batch.commit();
  }
}
